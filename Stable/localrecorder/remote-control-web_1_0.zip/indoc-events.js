function initializeremotecontrollerevents(){
    window.isrecording = false;

    $("#metatitle").on("input propertychange paste",function(){
        setMetaData('Title',$(this).val(), function(){
            btnPress('updateprojectinfo');
        });
    });
    $("#metadescription").on("input propertychange paste",function(){
        setMetaData('Description',$(this).val(), function(){
            btnPress('updateprojectinfo');
        });
    });
    $("#logout").on("click",function(){
        logout();
    });
    $("#recpausebtn").on("click",function(){
        window.isrecording = true;
        if(($("#recpausebtn p:first-child").attr("id") == "record" && $("#recpausebtn p:first-child").attr("id") != "pause") || ($("#recpausebtn p:first-child").attr("id") == "resume" && $("#recpausebtn p:first-child").attr("id") != "pause")){
            updatecurrentlylive(function(){
                if(window.currentlylive && $("#recpausebtn").attr("class") == "recstatus"){
                    setMetaData('Title',$("#metatitle").val(), function(){
                        setMetaData('Description',$("#metadescription").val(), function(){
                            btnPress('updateprojectinfo', function(){
                                $("#recpausebtn").attr("class", "liverecording").attr("title", "You are live right now");
                                $("#recpausebtn p:first-child").attr("id","pause").empty();
                                btnPress('Startpause');
                            });
                        });
                    });
                }else if(window.currentlylive){
                    //TODO: make a nice alert to show you can't press he pause button while being live!

                }
                else{
                    setMetaData('Title',$("#metatitle").val(), function(){
                        setMetaData('Description',$("#metadescription").val(), function(){
                            btnPress('updateprojectinfo', function(){
                                $("#recpausebtn p:first-child").attr("id","pause").empty();
                                $("#recpausebtn").attr("title", "Pause").removeAttr("class");
                                btnPress('Startpause');
                            });
                        });
                    });
                }
            });
        }
        else if($("#recpausebtn p:first-child").attr("id") == "pause"){
            updatecurrentlylive(function(){
                if(!window.currentlylive){
                    $("#recpausebtn").attr("title", "Resume");
                    $("#recpausebtn p:first-child").attr("id","resume").append("<p></p>").append("<p></p>");
                    btnPress('Startpause');
                }
            });
        }
    });
    $("#stopbtn").on("click",function(){
        btnPress('Stop');
        window.isrecording = false;
        window.currentlylive = false;
        $("#recpausebtn").attr("title", "Record").attr("class", "recstatus");
        $("#recpausebtn p:first-child").attr("id","record").empty();
    });
    $("#capturenowbtn").on("click",function(){
        btnPress('Capturenow');
    });

    $("#updatemetadata").on("click",function(){
        setMetaData('Title',$("#metatitle").val(), function(){
            setMetaData('Description',$("#metadescription").val(), function(){
                btnPress("updateprojectinfo");
            });
        });
    });

    $('input, textarea').on('keypress', function (e) {
        if(e.which == 13)  // the enter key code
        {
            $(this).next().next().next().next().focus();
            setMetaData('Title',$("#metatitle").val(), function(){
                setMetaData('Description',$("#metadescription").val(), function(){
                    btnPress("updateprojectinfo");
                });
            });
        }
    });

    $('input[type=checkbox]').each(function(){
        $(this).on("click",function(){
            var nexttag = $(this).next();
            if($(this).is(":checked")){
                if($(nexttag).attr("title") == "Autopublish"){
                    $(nexttag).attr("class", "activechkbx");
                    setConfiguration("autopublish", "true");
                }else if(window.isrecording == false){
                    $(nexttag).attr("class", "activechkbx");
                    if($(nexttag).attr("title") == "Live") setConfiguration("live", "true");
                    else if($(nexttag).attr("title") == "Presenter Only") setConfiguration("noslide", "true");
                }else{
                    //TODO: Make a nice alert to show you can't change the live and noslide checkbox while recoding.
                    $("errorfield").append("<p>Error: cant change this while recording!!</p>");
                }
            }else{
                if($(nexttag).attr("title") == "Autopublish"){
                    $(nexttag).removeAttr("class");
                    setConfiguration("autopublish", "false");
                }else if(window.isrecording == false){
                    $(nexttag).removeAttr("class");
                    if($(nexttag).attr("title") == "Live"){
                        setConfiguration("live", "false");
                        $("#errorfield").slideUp();
                    }
                    else if($(nexttag).attr("title") == "Presenter Only") setConfiguration("noslide", "false");
                }else{
                    $("errorfield").append("<p>Error: cant change this while recording!!</p>");
                }
            }
        });
    });

    $('#infofield').on('click', function(){
        $(this).slideUp(1000);
        setCookie("understandwarning","true", "10");
    });
}

function initializeloginevents(){

    $('#infofield').on('click', function(){
        $(this).slideUp(1000);
    });

    $('input').on('keypress', function (e) {
        if(e.which == 13)  // the enter key code
        {
            checkValidLogin();
        }
    });

    $("#Agreebtn").on("click", function(){
        understandcookies();
    });
    $("#loginbutton").on("click",function(){
        checkValidLogin();
    });

}