$(document).ready(function(){
    //Gets rid of any errors
    $("#errorfield").empty();

    if(getCookie("understandcookie") == "true") $('#cookieinfo').remove();

    initializeloginevents();
    checkCookiesEnables();
});

function checkValidLogin(){
    //TODO: change this
    var ip = location.host;
    //var ip = "10.128.70.25";
    var password = encodeURIComponent($('#passwordform').val());
    var Url = "http://" + ip + "?action=sendcommand&actiondetail=initializeremotecontrol&user=presentations2go&password=" + password;
    $.ajax({

        url: Url,
        type: "POST",
        dataType: "jsonp",
        async: false,

        success: function(json){
            setCookie("password", password);
            var j = $.parseJSON(json);
            setCookie("sessionId",j['sessionId'],0.3);
            if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile Safari|NokiaBrowser/i.test(navigator.userAgent) ) {
                window.location.href = "mobileremote_controller.html";
            }else{
                window.location.href = "remote_controller.html";
            }
        },
        error: function(errorThrown) {
            $("#errorfield").empty().prepend("Whoops, seems like there is something wrong with your login credentials!");
        }
    });

}
